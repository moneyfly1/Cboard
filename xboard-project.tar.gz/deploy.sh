#!/bin/bash

# XBoard 项目自动部署脚本
# 适用于宝塔面板环境
# 包含问题预防和自动修复功能

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 配置变量
PROJECT_NAME="xboard"
PROJECT_PATH="/www/wwwroot/$PROJECT_NAME"
BACKEND_PORT=8000
FRONTEND_PORT=3000
DOMAIN="yourdomain.com"

echo -e "${BLUE}🚀 XBoard 项目自动部署脚本${NC}"
echo "=================================="

# 检查是否为root用户
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}❌ 请使用root用户运行此脚本${NC}"
    exit 1
fi

# 环境检查函数
check_environment() {
    echo -e "${YELLOW}🔍 检查系统环境...${NC}"
    
    # 检查内存
    MEMORY_GB=$(free -g | awk 'NR==2{print $2}')
    if [ $MEMORY_GB -lt 2 ]; then
        echo -e "${RED}❌ 内存不足，建议至少2GB内存${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ 内存检查通过: ${MEMORY_GB}GB${NC}"
    
    # 检查磁盘空间
    DISK_SPACE=$(df -h / | awk 'NR==2{print $4}' | sed 's/G//')
    if [ $DISK_SPACE -lt 10 ]; then
        echo -e "${RED}❌ 磁盘空间不足，建议至少10GB可用空间${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ 磁盘空间检查通过: ${DISK_SPACE}GB可用${NC}"
    
    # 检查网络连接
    if ! ping -c 1 8.8.8.8 &> /dev/null; then
        echo -e "${RED}❌ 网络连接异常${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ 网络连接正常${NC}"
}

# 检查宝塔面板是否安装
if [ ! -f "/www/server/panel/BT-Panel" ]; then
    echo -e "${RED}❌ 未检测到宝塔面板，请先安装宝塔面板${NC}"
    exit 1
fi

echo -e "${GREEN}✅ 检测到宝塔面板${NC}"

# 执行环境检查
check_environment

# 创建项目目录
echo -e "${YELLOW}📁 创建项目目录...${NC}"
mkdir -p $PROJECT_PATH
cd $PROJECT_PATH

# 检查并安装Python环境
install_python() {
    echo -e "${YELLOW}🐍 检查Python环境...${NC}"
    if ! command -v python3 &> /dev/null; then
        echo -e "${YELLOW}⚠️ Python3未安装，正在安装...${NC}"
        apt update
        apt install -y python3 python3-pip python3-venv python3-dev
    fi
    
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
    PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d'.' -f1)
    PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d'.' -f2)
    
    if [ $PYTHON_MAJOR -lt 3 ] || ([ $PYTHON_MAJOR -eq 3 ] && [ $PYTHON_MINOR -lt 8 ]); then
        echo -e "${YELLOW}⚠️ Python版本过低，正在安装Python 3.9...${NC}"
        apt install -y software-properties-common
        add-apt-repository -y ppa:deadsnakes/ppa
        apt update
        apt install -y python3.9 python3.9-venv python3.9-dev python3.9-distutils
        update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.9 1
    fi
    
    echo -e "${GREEN}✅ Python版本: $(python3 --version)${NC}"
}

# 检查并安装Node.js环境
install_nodejs() {
    echo -e "${YELLOW}📦 检查Node.js环境...${NC}"
    if ! command -v node &> /dev/null; then
        echo -e "${YELLOW}⚠️ Node.js未安装，正在安装...${NC}"
        curl -fsSL https://deb.nodesource.com/setup_16.x | bash -
        apt-get install -y nodejs
    fi
    
    NODE_VERSION=$(node --version | cut -d'v' -f2)
    NODE_MAJOR=$(echo $NODE_VERSION | cut -d'.' -f1)
    
    if [ $NODE_MAJOR -lt 16 ]; then
        echo -e "${YELLOW}⚠️ Node.js版本过低，正在升级到16.x...${NC}"
        curl -fsSL https://deb.nodesource.com/setup_16.x | bash -
        apt-get install -y nodejs
    fi
    
    echo -e "${GREEN}✅ Node.js版本: $(node --version)${NC}"
}

# 安装编译工具
install_build_tools() {
    echo -e "${YELLOW}🔧 安装编译工具...${NC}"
    apt update
    apt install -y build-essential libffi-dev libssl-dev
    echo -e "${GREEN}✅ 编译工具安装完成${NC}"
}

# 执行环境安装
install_python
install_nodejs
install_build_tools

# 配置npm镜像源（解决网络问题）
echo -e "${YELLOW}🌐 配置npm镜像源...${NC}"
npm config set registry https://registry.npmmirror.com
echo -e "${GREEN}✅ npm镜像源配置完成${NC}"

# 创建虚拟环境
echo -e "${YELLOW}🔧 创建Python虚拟环境...${NC}"
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo -e "${GREEN}✅ 虚拟环境创建成功${NC}"
else
    echo -e "${GREEN}✅ 虚拟环境已存在${NC}"
fi

# 激活虚拟环境并安装依赖
echo -e "${YELLOW}📦 安装Python依赖...${NC}"
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
echo -e "${GREEN}✅ Python依赖安装完成${NC}"

# 安装前端依赖
install_frontend_deps() {
    echo -e "${YELLOW}📦 安装前端依赖...${NC}"
    cd frontend
    
    # 清理缓存
    npm cache clean --force
    
    # 设置内存限制
    export NODE_OPTIONS="--max-old-space-size=4096"
    
    # 安装依赖
    if ! npm install; then
        echo -e "${YELLOW}⚠️ npm install失败，尝试使用cnpm...${NC}"
        npm install -g cnpm --registry=https://registry.npmmirror.com
        cnpm install
    fi
    
    echo -e "${GREEN}✅ 前端依赖安装完成${NC}"
}

# 构建前端
build_frontend() {
    echo -e "${YELLOW}🏗️ 构建前端项目...${NC}"
    
    # 设置内存限制
    export NODE_OPTIONS="--max-old-space-size=4096"
    
    # 构建项目
    if ! npm run build; then
        echo -e "${YELLOW}⚠️ 构建失败，尝试清理后重新构建...${NC}"
        rm -rf node_modules
        rm -rf dist
        npm install
        npm run build
    fi
    
    echo -e "${GREEN}✅ 前端构建完成${NC}"
}

# 执行前端安装和构建
install_frontend_deps
build_frontend

# 返回项目根目录
cd ..

# 创建环境配置文件
echo -e "${YELLOW}⚙️ 创建环境配置文件...${NC}"
if [ ! -f ".env" ]; then
    cp env.example .env
    echo -e "${GREEN}✅ 环境配置文件已创建${NC}"
    echo -e "${YELLOW}⚠️ 请编辑 .env 文件配置数据库和其他参数${NC}"
else
    echo -e "${GREEN}✅ 环境配置文件已存在${NC}"
fi

# 初始化数据库
init_database() {
    echo -e "${YELLOW}🗄️ 初始化数据库...${NC}"
    
    # 检查数据库文件权限
    if [ -f "xboard.db" ]; then
        chmod 664 xboard.db
        chown www:www xboard.db
    fi
    
    # 初始化数据库
    if ! python -c "from app.core.database import init_database; init_database()"; then
        echo -e "${YELLOW}⚠️ 数据库初始化失败，尝试修复...${NC}"
        # 备份旧数据库
        if [ -f "xboard.db" ]; then
            cp xboard.db xboard.db.backup
        fi
        # 重新初始化
        python -c "from app.core.database import init_database; init_database()"
    fi
    
    echo -e "${GREEN}✅ 数据库初始化完成${NC}"
}

# 执行数据库初始化
init_database

# 设置文件权限
echo -e "${YELLOW}🔐 设置文件权限...${NC}"
chown -R www:www $PROJECT_PATH
chmod -R 755 $PROJECT_PATH
echo -e "${GREEN}✅ 文件权限设置完成${NC}"

# 创建PM2配置文件
echo -e "${YELLOW}📝 创建PM2配置文件...${NC}"
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [
    {
      name: 'xboard-backend',
      script: 'main.py',
      cwd: '$PROJECT_PATH',
      interpreter: '$PROJECT_PATH/venv/bin/python',
      args: '',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: $BACKEND_PORT
      }
    }
  ]
};
EOF
echo -e "${GREEN}✅ PM2配置文件创建完成${NC}"

# 创建Nginx配置文件
echo -e "${YELLOW}🌐 创建Nginx配置文件...${NC}"
cat > nginx.conf << EOF
server {
    listen 80;
    server_name $DOMAIN;
    root $PROJECT_PATH/frontend/dist;
    index index.html;

    # 前端静态文件
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # API代理
    location /api/ {
        proxy_pass http://127.0.0.1:$BACKEND_PORT;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # 静态文件缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF
echo -e "${GREEN}✅ Nginx配置文件创建完成${NC}"

# 创建启动脚本
echo -e "${YELLOW}🚀 创建启动脚本...${NC}"
cat > start.sh << EOF
#!/bin/bash
cd $PROJECT_PATH
source venv/bin/activate

# 启动后端服务
pm2 start ecosystem.config.js

# 检查服务状态
pm2 status

echo "服务启动完成！"
echo "后端服务: http://localhost:$BACKEND_PORT"
echo "前端服务: http://$DOMAIN"
EOF

chmod +x start.sh
echo -e "${GREEN}✅ 启动脚本创建完成${NC}"

# 创建停止脚本
echo -e "${YELLOW}🛑 创建停止脚本...${NC}"
cat > stop.sh << EOF
#!/bin/bash
cd $PROJECT_PATH

# 停止服务
pm2 stop xboard-backend
pm2 delete xboard-backend

echo "服务已停止！"
EOF

chmod +x stop.sh
echo -e "${GREEN}✅ 停止脚本创建完成${NC}"

# 创建重启脚本
echo -e "${YELLOW}🔄 创建重启脚本...${NC}"
cat > restart.sh << EOF
#!/bin/bash
cd $PROJECT_PATH

# 重启服务
pm2 restart xboard-backend

echo "服务已重启！"
EOF

chmod +x restart.sh
echo -e "${GREEN}✅ 重启脚本创建完成${NC}"

echo ""
echo -e "${GREEN}🎉 部署完成！${NC}"
echo "=================================="
echo -e "${BLUE}📋 后续步骤：${NC}"
echo "1. 编辑 .env 文件配置数据库和其他参数"
echo "2. 在宝塔面板中创建网站并配置域名"
echo "3. 上传Nginx配置文件到网站配置中"
echo "4. 运行 ./start.sh 启动服务"
echo ""
echo -e "${BLUE}📁 项目目录: $PROJECT_PATH${NC}"
echo -e "${BLUE}🌐 域名: $DOMAIN${NC}"
echo -e "${BLUE}🔧 后端端口: $BACKEND_PORT${NC}"
echo ""
echo -e "${YELLOW}⚠️ 注意事项：${NC}"
echo "- 请确保防火墙已开放80和443端口"
echo "- 请配置SSL证书以启用HTTPS"
echo "- 请定期备份数据库和代码"
echo ""
echo -e "${GREEN}✅ 部署脚本执行完成！${NC}"
