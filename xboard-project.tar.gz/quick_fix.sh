#!/bin/bash

# XBoard 项目快速修复脚本
# 用于解决部署过程中的常见问题

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

PROJECT_PATH="/www/wwwroot/xboard"

echo -e "${BLUE}🔧 XBoard 项目快速修复脚本${NC}"
echo "=================================="

# 检查是否为root用户
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}❌ 请使用root用户运行此脚本${NC}"
    exit 1
fi

# 修复函数
fix_permissions() {
    echo -e "${YELLOW}🔐 修复文件权限...${NC}"
    cd $PROJECT_PATH
    chown -R www:www $PROJECT_PATH
    chmod -R 755 $PROJECT_PATH
    chmod 664 xboard.db 2>/dev/null || true
    chmod 755 venv/bin/python 2>/dev/null || true
    echo -e "${GREEN}✅ 文件权限修复完成${NC}"
}

fix_python_deps() {
    echo -e "${YELLOW}🐍 修复Python依赖...${NC}"
    cd $PROJECT_PATH
    source venv/bin/activate
    pip install --upgrade pip
    pip install -r requirements.txt --force-reinstall
    echo -e "${GREEN}✅ Python依赖修复完成${NC}"
}

fix_node_deps() {
    echo -e "${YELLOW}📦 修复Node.js依赖...${NC}"
    cd $PROJECT_PATH/frontend
    rm -rf node_modules
    rm -rf dist
    npm cache clean --force
    export NODE_OPTIONS="--max-old-space-size=4096"
    npm install
    npm run build
    echo -e "${GREEN}✅ Node.js依赖修复完成${NC}"
}

fix_database() {
    echo -e "${YELLOW}🗄️ 修复数据库...${NC}"
    cd $PROJECT_PATH
    source venv/bin/activate
    
    # 备份数据库
    if [ -f "xboard.db" ]; then
        cp xboard.db xboard.db.backup.$(date +%Y%m%d_%H%M%S)
    fi
    
    # 重新初始化数据库
    python -c "from app.core.database import init_database; init_database()"
    echo -e "${GREEN}✅ 数据库修复完成${NC}"
}

fix_port_conflict() {
    echo -e "${YELLOW}🔌 修复端口冲突...${NC}"
    
    # 检查端口占用
    if lsof -i :8000 >/dev/null 2>&1; then
        echo -e "${YELLOW}⚠️ 端口8000被占用，正在释放...${NC}"
        PID=$(lsof -ti :8000)
        kill -9 $PID 2>/dev/null || true
        sleep 2
    fi
    
    if lsof -i :3000 >/dev/null 2>&1; then
        echo -e "${YELLOW}⚠️ 端口3000被占用，正在释放...${NC}"
        PID=$(lsof -ti :3000)
        kill -9 $PID 2>/dev/null || true
        sleep 2
    fi
    
    echo -e "${GREEN}✅ 端口冲突修复完成${NC}"
}

fix_nginx_config() {
    echo -e "${YELLOW}🌐 修复Nginx配置...${NC}"
    
    # 创建正确的Nginx配置
    cat > /tmp/xboard_nginx.conf << 'EOF'
server {
    listen 80;
    server_name yourdomain.com;
    root /www/wwwroot/xboard/frontend/dist;
    index index.html;

    # 前端静态文件
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API代理
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # 解决跨域问题
        add_header Access-Control-Allow-Origin *;
        add_header Access-Control-Allow-Methods 'GET, POST, PUT, DELETE, OPTIONS';
        add_header Access-Control-Allow-Headers 'DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Authorization';
        
        if ($request_method = 'OPTIONS') {
            return 204;
        }
    }

    # 静态文件缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF
    
    echo -e "${GREEN}✅ Nginx配置文件已生成: /tmp/xboard_nginx.conf${NC}"
    echo -e "${YELLOW}⚠️ 请手动将此配置添加到宝塔面板的网站配置中${NC}"
}

fix_pm2_config() {
    echo -e "${YELLOW}⚙️ 修复PM2配置...${NC}"
    cd $PROJECT_PATH
    
    # 停止现有进程
    pm2 stop xboard-backend 2>/dev/null || true
    pm2 delete xboard-backend 2>/dev/null || true
    
    # 创建PM2配置
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'xboard-backend',
    script: 'main.py',
    cwd: '$PROJECT_PATH',
    interpreter: '$PROJECT_PATH/venv/bin/python',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production'
    }
  }]
};
EOF
    
    # 启动服务
    pm2 start ecosystem.config.js
    pm2 save
    pm2 startup
    
    echo -e "${GREEN}✅ PM2配置修复完成${NC}"
}

# 主菜单
show_menu() {
    echo -e "${BLUE}请选择要修复的问题:${NC}"
    echo "1. 修复文件权限"
    echo "2. 修复Python依赖"
    echo "3. 修复Node.js依赖"
    echo "4. 修复数据库"
    echo "5. 修复端口冲突"
    echo "6. 修复Nginx配置"
    echo "7. 修复PM2配置"
    echo "8. 全部修复"
    echo "0. 退出"
    echo ""
    read -p "请输入选项 (0-8): " choice
}

# 执行修复
execute_fix() {
    case $1 in
        1) fix_permissions ;;
        2) fix_python_deps ;;
        3) fix_node_deps ;;
        4) fix_database ;;
        5) fix_port_conflict ;;
        6) fix_nginx_config ;;
        7) fix_pm2_config ;;
        8) 
            echo -e "${YELLOW}🔄 执行全部修复...${NC}"
            fix_permissions
            fix_python_deps
            fix_node_deps
            fix_database
            fix_port_conflict
            fix_nginx_config
            fix_pm2_config
            echo -e "${GREEN}🎉 全部修复完成！${NC}"
            ;;
        0) 
            echo -e "${GREEN}👋 退出修复脚本${NC}"
            exit 0
            ;;
        *) 
            echo -e "${RED}❌ 无效选项${NC}"
            ;;
    esac
}

# 主循环
while true; do
    show_menu
    execute_fix $choice
    echo ""
    read -p "按回车键继续..." dummy
    clear
done
