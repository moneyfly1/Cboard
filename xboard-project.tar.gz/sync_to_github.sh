#!/bin/bash

# 强制同步项目到GitHub master分支
# 删除main分支的代码

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 强制同步项目到GitHub${NC}"
echo "=================================="

# 检查是否在Git仓库中
if [ ! -d ".git" ]; then
    echo -e "${RED}❌ 当前目录不是Git仓库${NC}"
    exit 1
fi

# 添加所有文件到暂存区
echo -e "${YELLOW}📁 添加所有文件到暂存区...${NC}"
git add .

# 提交所有更改
echo -e "${YELLOW}💾 提交所有更改...${NC}"
git commit -m "Update project: clean up test files and add deployment scripts

- 删除所有测试文件和无用文件
- 添加VPS部署脚本和文档
- 添加问题解决指南
- 优化项目结构
- 关闭节点采集功能
- 修复前端轮询问题"

# 检查远程仓库
echo -e "${YELLOW}🔍 检查远程仓库...${NC}"
if ! git remote get-url origin >/dev/null 2>&1; then
    echo -e "${RED}❌ 未配置远程仓库，请先添加远程仓库${NC}"
    echo -e "${YELLOW}示例: git remote add origin https://github.com/username/repository.git${NC}"
    exit 1
fi

REMOTE_URL=$(git remote get-url origin)
echo -e "${GREEN}✅ 远程仓库: $REMOTE_URL${NC}"

# 强制推送到master分支
echo -e "${YELLOW}📤 强制推送到master分支...${NC}"
git push origin HEAD:master --force

# 删除main分支（如果存在）
echo -e "${YELLOW}🗑️ 删除main分支...${NC}"
if git show-ref --verify --quiet refs/heads/main; then
    git branch -D main
    echo -e "${GREEN}✅ 本地main分支已删除${NC}"
fi

# 删除远程main分支（如果存在）
if git ls-remote --heads origin main | grep -q main; then
    git push origin --delete main
    echo -e "${GREEN}✅ 远程main分支已删除${NC}"
else
    echo -e "${GREEN}✅ 远程main分支不存在${NC}"
fi

# 设置master为默认分支
echo -e "${YELLOW}⚙️ 设置master为默认分支...${NC}"
git branch -M master
git push -u origin master

echo ""
echo -e "${GREEN}🎉 同步完成！${NC}"
echo "=================================="
echo -e "${BLUE}📋 完成的操作：${NC}"
echo "✅ 添加所有文件到暂存区"
echo "✅ 提交所有更改"
echo "✅ 强制推送到master分支"
echo "✅ 删除main分支"
echo "✅ 设置master为默认分支"
echo ""
echo -e "${BLUE}🌐 项目地址: $REMOTE_URL${NC}"
echo -e "${BLUE}📁 默认分支: master${NC}"
echo ""
echo -e "${YELLOW}💡 提示：${NC}"
echo "- 项目已成功同步到GitHub"
echo "- 所有测试文件已清理"
echo "- 部署脚本已添加"
echo "- 可以开始VPS部署了"
