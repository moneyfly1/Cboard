<template>
  <div class="macos-tutorials">
    <el-collapse v-model="activeNames">
      <!-- Flash -->
      <el-collapse-item title="Flash" name="flash-macos">
        <div class="tutorial-content">
          <h3>1. 软件下载</h3>
          <p>点击上方"立即下载"按钮下载 Flash 最新版本。</p>
          
          <h3>2. 安装步骤</h3>
          <ol>
            <li>下载完成后，双击 .dmg 文件</li>
            <li>将 Flash 拖拽到 Applications 文件夹</li>
            <li>在应用程序文件夹中找到 Flash 并双击启动</li>
            <li>首次运行可能提示"无法验证开发者"，请按以下步骤操作：
              <ul>
                <li>打开"系统偏好设置" → "安全性与隐私"</li>
                <li>点击"仍要打开"按钮</li>
                <li>或者右键点击应用，选择"打开"</li>
              </ul>
            </li>
          </ol>
          
          <h3>3. 导入订阅</h3>
          <div class="subscription-methods">
            <h4>方法一：复制订阅链接</h4>
            <ol>
              <li>在用户仪表盘中，复制"Clash订阅地址"</li>
              <li>打开 Flash</li>
              <li>点击"配置" → "从URL下载"</li>
              <li>粘贴订阅链接，点击"下载"</li>
              <li>选择下载的配置文件</li>
            </ol>
            
            <h4>方法二：一键导入</h4>
            <ol>
              <li>在用户仪表盘中，点击"Flash"按钮</li>
              <li>选择"一键导入"</li>
              <li>软件会自动打开并导入配置</li>
            </ol>
          </div>
          
          <h3>4. 使用方法</h3>
          <ol>
            <li>导入配置后，在"代理"页面选择节点</li>
            <li>点击"系统代理"开启系统代理</li>
            <li>选择"规则模式"或"全局模式"</li>
            <li>开始使用代理服务</li>
          </ol>
          
          <div class="tips">
            <h4>💡 使用技巧</h4>
            <ul>
              <li>Flash 是专为 macOS 设计的轻量级代理软件</li>
              <li>启动速度快，资源占用少</li>
              <li>建议使用"规则模式"进行智能分流</li>
              <li>可以设置开机自启动</li>
            </ul>
          </div>
        </div>
      </el-collapse-item>

      <!-- Mihomo Part -->
      <el-collapse-item title="Mihomo Part" name="mihomo-macos">
        <div class="tutorial-content">
          <h3>1. 软件下载</h3>
          <p>点击上方"立即下载"按钮下载 Mihomo Part 最新版本。</p>
          
          <h3>2. 安装步骤</h3>
          <ol>
            <li>下载完成后，双击 .dmg 文件</li>
            <li>将 Mihomo Part 拖拽到 Applications 文件夹</li>
            <li>在应用程序文件夹中找到 Mihomo Part 并双击启动</li>
            <li>首次运行可能提示"无法验证开发者"，请按以下步骤操作：
              <ul>
                <li>打开"系统偏好设置" → "安全性与隐私"</li>
                <li>点击"仍要打开"按钮</li>
                <li>或者右键点击应用，选择"打开"</li>
              </ul>
            </li>
          </ol>
          
          <h3>3. 导入订阅</h3>
          <div class="subscription-methods">
            <h4>方法一：复制订阅链接</h4>
            <ol>
              <li>在用户仪表盘中，复制"Clash订阅地址"</li>
              <li>打开 Mihomo Part</li>
              <li>点击"配置" → "从URL下载"</li>
              <li>粘贴订阅链接，点击"下载"</li>
              <li>选择下载的配置文件</li>
            </ol>
            
            <h4>方法二：一键导入</h4>
            <ol>
              <li>在用户仪表盘中，点击"Mihomo Part"按钮</li>
              <li>选择"一键导入"</li>
              <li>软件会自动打开并导入配置</li>
            </ol>
          </div>
          
          <h3>4. 使用方法</h3>
          <ol>
            <li>导入配置后，在"代理"页面选择节点</li>
            <li>点击"系统代理"开启系统代理</li>
            <li>选择"规则模式"或"全局模式"</li>
            <li>开始使用代理服务</li>
          </ol>
          
          <div class="tips">
            <h4>💡 使用技巧</h4>
            <ul>
              <li>Mihomo Part 是 Clash 的增强版本，功能更强大</li>
              <li>支持更多协议和功能</li>
              <li>建议使用"规则模式"进行智能分流</li>
              <li>可以设置开机自启动</li>
            </ul>
          </div>
        </div>
      </el-collapse-item>

      <!-- Sparkle -->
      <el-collapse-item title="Sparkle" name="sparkle-macos">
        <div class="tutorial-content">
          <h3>1. 软件下载</h3>
          <p>点击上方"立即下载"按钮下载 Sparkle 最新版本。</p>
          
          <h3>2. 安装步骤</h3>
          <ol>
            <li>下载完成后，双击 .dmg 文件</li>
            <li>将 Sparkle 拖拽到 Applications 文件夹</li>
            <li>在应用程序文件夹中找到 Sparkle 并双击启动</li>
            <li>首次运行可能提示"无法验证开发者"，请按以下步骤操作：
              <ul>
                <li>打开"系统偏好设置" → "安全性与隐私"</li>
                <li>点击"仍要打开"按钮</li>
                <li>或者右键点击应用，选择"打开"</li>
              </ul>
            </li>
          </ol>
          
          <h3>3. 导入订阅</h3>
          <div class="subscription-methods">
            <h4>方法一：复制订阅链接</h4>
            <ol>
              <li>在用户仪表盘中，复制"Clash订阅地址"</li>
              <li>打开 Sparkle</li>
              <li>点击"配置" → "从URL下载"</li>
              <li>粘贴订阅链接，点击"下载"</li>
              <li>选择下载的配置文件</li>
            </ol>
            
            <h4>方法二：一键导入</h4>
            <ol>
              <li>在用户仪表盘中，点击"Sparkle"按钮</li>
              <li>选择"一键导入"</li>
              <li>软件会自动打开并导入配置</li>
            </ol>
          </div>
          
          <h3>4. 使用方法</h3>
          <ol>
            <li>导入配置后，在"代理"页面选择节点</li>
            <li>点击"系统代理"开启系统代理</li>
            <li>选择"规则模式"或"全局模式"</li>
            <li>开始使用代理服务</li>
          </ol>
          
          <div class="tips">
            <h4>💡 使用技巧</h4>
            <ul>
              <li>Sparkle 界面简洁，操作简单</li>
              <li>支持自动更新订阅</li>
              <li>建议使用"规则模式"进行智能分流</li>
              <li>可以设置开机自启动</li>
            </ul>
          </div>
        </div>
      </el-collapse-item>
    </el-collapse>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const activeNames = ref(['flash-macos'])
</script>

<style scoped>
.macos-tutorials {
  padding: 20px;
}

.tutorial-content {
  line-height: 1.6;
}

.tutorial-content h3 {
  color: #2c3e50;
  margin-top: 20px;
  margin-bottom: 10px;
  border-left: 4px solid #f39c12;
  padding-left: 10px;
}

.tutorial-content h4 {
  color: #34495e;
  margin-top: 15px;
  margin-bottom: 8px;
}

.tutorial-content ol, .tutorial-content ul {
  margin: 10px 0;
  padding-left: 20px;
}

.tutorial-content li {
  margin: 5px 0;
}

.subscription-methods {
  background: #f8f9fa;
  padding: 15px;
  border-radius: 8px;
  margin: 15px 0;
}

.tips {
  background: #e8f5e8;
  padding: 15px;
  border-radius: 8px;
  margin: 15px 0;
  border-left: 4px solid #27ae60;
}

.tips h4 {
  color: #27ae60;
  margin-top: 0;
}
</style>
