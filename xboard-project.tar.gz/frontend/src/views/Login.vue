<template>
  <div class="login-container">
    <div class="login-box">
      <div class="login-header">
        <h1>XBoard Modern</h1>
        <p>现代化订阅管理系统</p>
      </div>
      
      <div class="login-form">
        <div class="form-item">
                  <input
          v-model="loginForm.username"
          type="text"
          placeholder="用户名或邮箱"
          class="login-input"
          autocomplete="username"
        />
        </div>
        
        <div class="form-item">
          <input
            v-model="loginForm.password"
            type="password"
            placeholder="密码"
            class="login-input"
            autocomplete="current-password"
            @keyup.enter="handleLogin"
          />
        </div>
        
        <div class="form-item">
          <button
            type="button"
            :disabled="loading"
            class="login-button"
            @click="handleLogin"
          >
            {{ loading ? '登录中...' : '登录' }}
          </button>
        </div>
        
        <div class="form-item">
          <button
            type="button"
            class="debug-button"
            @click="checkState"
          >
            检查状态
          </button>
        </div>
        
        <div class="login-actions">
          <el-link type="primary" @click="$router.push('/register')">
            注册账户
          </el-link>
          <el-link type="primary" @click="$router.push('/forgot-password')">
            忘记密码？
          </el-link>
        </div>
      </div>
    </div>
    
    <!-- 忘记密码对话框 -->
    <el-dialog
      v-model="showForgotPassword"
      title="忘记密码"
      width="400px"
    >
      <el-form
        ref="forgotForm"
        :model="forgotForm"
        :rules="forgotRules"
      >
        <el-form-item prop="email">
                  <el-input
          v-model="forgotForm.email"
          placeholder="请输入邮箱地址"
          type="email"
        />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <el-button @click="showForgotPassword = false">取消</el-button>
        <el-button 
          type="primary" 
          :loading="forgotLoading"
          @click="handleForgotPassword"
        >
          发送重置邮件
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { ref, reactive, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '@/store/auth'

export default {
  name: 'Login',
  setup() {
    const router = useRouter()
    const authStore = useAuthStore()
    
    const loginForm = reactive({
      username: '',
      password: ''
    })
    
    const forgotForm = reactive({
      email: ''
    })
    
    const loading = ref(false)
    const forgotLoading = ref(false)
    const showForgotPassword = ref(false)
    
    const loginRules = {
      username: [
        { required: true, message: '请输入用户名或邮箱', trigger: 'blur' }
      ],
      password: [
        { required: true, message: '请输入密码', trigger: 'blur' },
        { min: 6, message: '密码长度不能少于6位', trigger: 'blur' }
      ]
    }
    
    const forgotRules = {
      email: [
        { required: true, message: '请输入邮箱地址', trigger: 'blur' },
        { type: 'email', message: '请输入正确的邮箱格式', trigger: 'blur' }
      ]
    }
    
    const handleLogin = async () => {
      loading.value = true

      try {
        console.log('开始登录，用户名:', loginForm.username)
        console.log('开始登录，密码:', loginForm.password)

        const result = await authStore.login(loginForm)
        console.log('登录结果:', result)

        if (result.success) {
          ElMessage.success('登录成功')

          // 添加调试信息
          console.log('登录成功，用户数据:', authStore.user)
          console.log('用户权限状态:', authStore.isAdmin)
          console.log('用户ID:', authStore.user?.id)
          console.log('用户名:', authStore.user?.username)
          console.log('邮箱:', authStore.user?.email)
          console.log('is_admin字段:', authStore.user?.is_admin)
          console.log('localStorage中的用户数据:', localStorage.getItem('user'))

          // 确保用户信息已经更新后再跳转
          await nextTick()

          console.log('跳转前再次检查用户状态:')
          console.log('isAdmin:', authStore.isAdmin)
          console.log('user:', authStore.user)

          // 根据用户权限跳转到不同页面
          if (authStore.isAdmin) {
            console.log('跳转到管理员界面')
            await router.push('/admin/dashboard')
          } else {
            console.log('跳转到普通用户界面')
            await router.push('/dashboard')
          }

          console.log('跳转完成')
        } else {
          console.log('登录失败:', result.message)
          ElMessage.error(result.message)
        }
      } catch (error) {
        console.error('登录异常:', error)
        console.error('错误详情:', error.response?.data)
        ElMessage.error('登录失败，请重试')
      } finally {
        loading.value = false
      }
    }
    
    const handleForgotPassword = async () => {
      forgotLoading.value = true
      
      try {
        const result = await authStore.forgotPassword(forgotForm.email)
        if (result.success) {
          ElMessage.success(result.message)
          showForgotPassword.value = false
          forgotForm.email = ''
        } else {
          ElMessage.error(result.message)
        }
      } catch (error) {
        ElMessage.error('发送失败，请重试')
      } finally {
        forgotLoading.value = false
      }
    }

    const checkState = () => {
      console.log('当前用户状态:')
      console.log('用户数据:', authStore.user)
      console.log('用户权限状态:', authStore.isAdmin)
      console.log('用户ID:', authStore.user?.id)
      console.log('用户名:', authStore.user?.username)
      console.log('邮箱:', authStore.user?.email)
      console.log('is_admin字段:', authStore.user?.is_admin)
      console.log('localStorage中的用户数据:', localStorage.getItem('user'))
    }
    
    return {
      loginForm,
      forgotForm,
      loading,
      forgotLoading,
      showForgotPassword,
      loginRules,
      forgotRules,
      handleLogin,
      handleForgotPassword,
      checkState
    }
  }
}
</script>

<style scoped>
.login-container {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 20px;
}

.login-box {
  background: white;
  border-radius: 12px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
  padding: 40px;
  width: 100%;
  max-width: 400px;
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.login-header h1 {
  color: #1677ff;
  font-size: 28px;
  margin-bottom: 8px;
  font-weight: 600;
}

.login-header p {
  color: #666;
  font-size: 14px;
  margin: 0;
}

.login-form {
  margin-top: 20px;
}

.form-item {
  margin-bottom: 20px;
}

.login-input {
  width: 100%;
  height: 44px;
  padding: 0 16px;
  border: 1px solid #dcdfe6;
  border-radius: 6px;
  font-size: 16px;
  outline: none;
  transition: border-color 0.3s;
}

.login-input:focus {
  border-color: #1677ff;
  box-shadow: 0 0 0 2px rgba(22, 119, 255, 0.1);
}

.login-input::placeholder {
  color: #a8abb2;
}

.login-button {
  width: 100%;
  height: 44px;
  font-size: 16px;
  font-weight: 500;
  background: #1677ff;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.login-button:hover:not(:disabled) {
  background: #0958d9;
}

.login-button:disabled {
  background: #a8abb2;
  cursor: not-allowed;
}

.debug-button {
  width: 100%;
  height: 44px;
  font-size: 16px;
  font-weight: 500;
  background: #409eff; /* A different color for debugging */
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.debug-button:hover:not(:disabled) {
  background: #3a8ee6;
}

.debug-button:disabled {
  background: #a8abb2;
  cursor: not-allowed;
}

.login-actions {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
  font-size: 14px;
}

@media (max-width: 480px) {
  .login-box {
    padding: 30px 20px;
  }
  
  .login-header h1 {
    font-size: 24px;
  }
}
</style> 